/**
 * Java assignment 4 - CP2280 - fall 2024
 *
 * this package contains 2 classes:
 * FibonacciCalc.java - contains all the logic for the fibonacci calculator.
 * FunWithFibonacciCalc.java - contains the UI and calls methods based on what is selected by the user.
 *
 * @author Greg Saunders
 */

package assignments.A4;
